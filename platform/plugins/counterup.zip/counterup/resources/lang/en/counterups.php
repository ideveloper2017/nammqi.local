<?php

return [
    'name'   => 'Counterups',
    'create' => 'New counterups',
    'edit'   => 'Edit counterups',
];
