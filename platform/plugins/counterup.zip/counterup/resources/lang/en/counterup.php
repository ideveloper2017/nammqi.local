<?php

return [
    'name'   => 'Counterups',
    'create' => 'New counterup',
    'edit'   => 'Edit counterup',
];
