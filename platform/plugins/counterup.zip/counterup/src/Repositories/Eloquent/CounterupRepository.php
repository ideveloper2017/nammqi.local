<?php

namespace Botble\Counterup\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Counterup\Repositories\Interfaces\CounterupInterface;

class CounterupRepository extends RepositoriesAbstract implements CounterupInterface
{
}
