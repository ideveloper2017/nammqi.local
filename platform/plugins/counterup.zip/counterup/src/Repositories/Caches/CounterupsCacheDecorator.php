<?php

namespace Botble\Counterup\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Counterup\Repositories\Interfaces\CounterupsInterface;

class CounterupsCacheDecorator extends CacheAbstractDecorator implements CounterupsInterface
{

}
