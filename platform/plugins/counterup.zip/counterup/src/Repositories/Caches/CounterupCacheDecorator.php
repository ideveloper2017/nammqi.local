<?php

namespace Botble\Counterup\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Counterup\Repositories\Interfaces\CounterupInterface;

class CounterupCacheDecorator extends CacheAbstractDecorator implements CounterupInterface
{

}
