<?php

namespace Botble\Counterup\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface CounterupInterface extends RepositoryInterface
{
}
