<?php

if (!defined('COUNTERUP_MODULE_SCREEN_NAME')) {
    define('COUNTERUP_MODULE_SCREEN_NAME', 'counterup');
}

